package main;

import("fmt"
		"math/rand"
		"time"
	)

func exec(tempo int) int{
	n:= rand.Intn(tempo) + 1
	time.Sleep(time.Duration(n)*time.Millisecond)
	return n
}

func aux(max_sleep_ms int) chan int{
	ch:= make(chan int)
	go addToChan(ch,max_sleep_ms)
	return ch
}



func addToChan(ch chan int, valor int){
	for range 1000{
		ch <- exec(valor)
	}
}

func main(){
	ch1 := aux(rand.Intn(20))
	ch2 := aux(rand.Intn(30))
	count:=0
	for range 500{
		n:= <- ch1
		count+=n
		x:= <- ch2
		count+=x
	}
	fmt.Println(count)
}